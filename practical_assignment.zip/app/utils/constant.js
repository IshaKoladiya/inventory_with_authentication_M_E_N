module.exports = {
    // COMMON Const
    
    RESP_CODE: 'code',
    LOG_SUCCESSFUL: "EXECUTE SUCCESSFULLY" 


 }
